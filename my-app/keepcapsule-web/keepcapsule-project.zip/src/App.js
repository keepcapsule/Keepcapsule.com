// src/App.js
import React, { useState } from "react";
import "./App.css";

function App() {
  const [clicked, setClicked] = useState(false);

  return (
    <div className="App">
      <header>
      console.log("✅ React is running and rendering.");
        <h1>Test Login Button</h1>
        <button onClick={() => setClicked(true)} className="login-btn">
          Login / Sign Up
        </button>
        {clicked && <p>✅ Button Clicked!</p>}
      </header>
    </div>
  );
}

export default App;
