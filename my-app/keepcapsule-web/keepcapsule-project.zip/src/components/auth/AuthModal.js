import React from "react";
import "./auth.css";

const AuthModal = ({
  showModal,
  setShowModal,
  isLogin,
  setIsLogin,
  email,
  setEmail,
  password,
  setPassword,
  handleAuth
}) => {
  if (!showModal) return null;

  return (
    <div className="auth-modal">
      <div className="auth-content">
        <button className="auth-close" onClick={() => setShowModal(false)}>✖</button>
        <h2>{isLogin ? "Login" : "Sign Up"}</h2>
        <form onSubmit={handleAuth}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            required
          />
          <button type="submit" className="auth-button">
            {isLogin ? "Login" : "Sign Up"}
          </button>
        </form>
        <div className="auth-controls">
          <p onClick={() => setIsLogin(prev => !prev)} style={{ cursor: "pointer" }}>
            {isLogin ? "No account? Sign up" : "Already have an account? Login"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;