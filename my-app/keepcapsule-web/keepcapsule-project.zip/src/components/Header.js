import React from "react";

const Header = ({ onLoginClick, isLoggedIn, onLogout }) => {
  return (
    <header>
      <nav>
        <div className="logo">KeepCapsule</div>
        <ul className="nav-links">
          <li><a href="#about">About</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#join">Join Us</a></li>
        </ul>
        <div style={{ marginTop: '10px' }}>
          {isLoggedIn ? (
            <button onClick={onLogout} className="login-btn">Logout</button>
          ) : (
            <button onClick={onLoginClick} className="login-btn">Login / Sign Up</button>
          )}
        </div>
      </nav>
    </header>
  );
};

export default Header;